<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Product</h2>
				
            </div>
            <div class="pull-right">
					<a class="btn btn-primary" href="<?php echo e(URL::to('cart')); ?>"> Back</a>
				</div>
        </div>
    </div>

    <?php if(count($errors) < 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
           
        </div>
    <?php endif; ?>
	
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
    <div class="row">
		<?php echo Form::open(array('url' => 'cart/update','method'=>'PUT')); ?>

		<?php echo Form::text('id', $product->id, array('placeholder' => 'Name','class' => 'form-control hidden', 'value' =>$product->name )); ?>

		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Name:</strong>
				<?php echo Form::text('name', $product->name, array('placeholder' => 'Name','class' => 'form-control', 'value' =>$product->name )); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Price:</strong>
				<?php echo Form::number('price', $product->price, array('placeholder' => 'Price','class' => 'form-control', 'value' =>$product->price)); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Quantity:</strong>
				<?php echo Form::number('quantity', $product->quantity, array('placeholder' => 'Quantity','class' => 'form-control', 'value' =>$product->quantity)); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Size:</strong>
				<?php echo Form::number('size', $product->size, array('placeholder' => 'Size','class' => 'form-control', 'value' =>$product->size)); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12 text-center">
				<button type="submit" class="btn btn-primary">Submit</button>
		</div>
		<?php echo Form::close(); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>