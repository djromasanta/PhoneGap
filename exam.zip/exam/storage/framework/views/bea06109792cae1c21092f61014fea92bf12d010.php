<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Product</h2>
				<div class="pull-right">
					<a class="btn btn-primary" href="<?php echo e(URL::to('cart')); ?>"> Back</a>
				</div>
            </div>
            
        </div>
    </div>

    <?php if(count($errors) < 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
           
        </div>
    <?php endif; ?>

    <div class="row">
		<?php echo Form::open(array('url' => 'cart','method'=>'POST')); ?>

		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Name:</strong>
				<?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Price:</strong>
				<?php echo Form::number('price', null, array('placeholder' => 'Price','class' => 'form-control')); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Quantity:</strong>
				<?php echo Form::number('quantity', null, array('placeholder' => 'Quantity','class' => 'form-control')); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group">
				<strong>Size:</strong>
				<?php echo Form::number('size', null, array('placeholder' => 'Size','class' => 'form-control')); ?>

			</div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12 text-center">
				<button type="submit" class="btn btn-primary">Submit</button>
		</div>
		<?php echo Form::close(); ?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>