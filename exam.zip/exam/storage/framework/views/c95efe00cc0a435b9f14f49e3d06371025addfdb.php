<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Products</h2>
            </div>
        </div>
    </div>
	
	 <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
			<th>Size</th>
			<th>Product ID</th>
            <th width="280px">Action</th>
        </tr>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->price); ?></td>
		<td><?php echo e($product->quantity); ?></td>
		<td><?php echo e($product->size); ?></td>
		<td><?php echo e($product->product_id); ?></td>
        <td>
			<a class="btn btn-info" href="#" onclick="addToCart('<?php echo e($product->name); ?>', <?php echo e($product->price); ?> )" >Add to Cart</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
	
	<table class="table table-bordered">
        <tr>
            <th colspan="2" align="center">Cart</th>
        </tr>
		<tr>
            <th>Name</th>
            <th>Price</th>
        </tr>
		<tbody id="cart">
		</tbody>
		<tfoot>
			<td>TOTAL</td>
			<td id="price"></td>
		</tfoot>
    </table>

<script>
var totalprice = 0
function addToCart(name, price){
	totalPrice(price);
	$("#cart").append("<tr><td>"+name+"</td><td>"+price+"</td></tr>");
}

function totalPrice(price){
	
	totalprice += price;
	$("#price").text(totalprice);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>