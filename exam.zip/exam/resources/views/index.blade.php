@extends('layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Cart</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ URL::to('cart/create') }}"> Create New Product</a>
            </div>
        </div>
    </div>
	
	 @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
			<th>Size</th>
			<th>Product ID</th>
            <th width="280px">Action</th>
        </tr>
    @foreach ($products as $product)
    <tr>
        <td>{{ $product->name}}</td>
        <td>{{ $product->price}}</td>
		<td>{{ $product->quantity}}</td>
		<td>{{ $product->size}}</td>
		<td>{{ $product->product_id}}</td>
        <td>
			<a class="btn btn-info" href="{{ URL::to('cart/' . $product->id . '/edit') }}">Edit</a>
			 {{ Form::open(array('url' => 'cart/' . $product->id, 'class' => 'pull-right')) }}
                    {{ Form::hidden('_method', 'DELETE') }}
                    {{ Form::submit('Delete', array('class' => 'btn btn-warning')) }}
                {{ Form::close() }}

        </td>
    </tr>
    @endforeach
    </table>

@endsection