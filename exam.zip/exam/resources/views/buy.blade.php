@extends('layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Products</h2>
            </div>
        </div>
    </div>
	
	 @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
			<th>Size</th>
			<th>Product ID</th>
            <th width="280px">Action</th>
        </tr>
    @foreach ($products as $product)
    <tr>
        <td>{{ $product->name}}</td>
        <td>{{ $product->price}}</td>
		<td>{{ $product->quantity}}</td>
		<td>{{ $product->size}}</td>
		<td>{{ $product->product_id}}</td>
        <td>
			<a class="btn btn-info" href="#" onclick="addToCart('{{ $product->name}}', {{ $product->price}} )" >Add to Cart</a>
        </td>
    </tr>
    @endforeach
    </table>
	
	<table class="table table-bordered">
        <tr>
            <th colspan="2" align="center">Cart</th>
        </tr>
		<tr>
            <th>Name</th>
            <th>Price</th>
        </tr>
		<tbody id="cart">
		</tbody>
		<tfoot>
			<td>TOTAL</td>
			<td id="price"></td>
		</tfoot>
    </table>

<script>
var totalprice = 0
function addToCart(name, price){
	totalPrice(price);
	$("#cart").append("<tr><td>"+name+"</td><td>"+price+"</td></tr>");
}

function totalPrice(price){
	
	totalprice += price;
	$("#price").text(totalprice);
}
</script>
@endsection