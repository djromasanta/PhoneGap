<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Redirect;
use Request;
use Session;
use App\Cart;

class CartController extends Controller
{
    public function index()
    {
        $cart = DB::table('carts')->paginate(15);
        return view('index', ['products' => $cart]);
    }
	
	 public function create()
    {
        return view('create');
    }
	
	
	
	public function store(Request $request){
       
			$name = Request::input('name');
			$price = Request::input('price');
			$quantity = Request::input('quantity');
			$size = Request::input('size');
			$product_id =  $this->generateUniqueId(4);
	
			DB::table('carts')->insert([
				[
					'name' => $name, 
					'price' => $price,
					'quantity' => $quantity,
					'size' => $size,
					'product_id' => $product_id
				]
			]);
			
            Session::flash('success', 'Successfully created product!');
            return Redirect::to('cart');
    }


    public function edit($id)
    {
        $cart = DB::table('carts')->where('id', '=', $id)->get();
		return view('edit', ['products' => $cart]);
    }

    
    public function update(Request $request)
    {
		$id = Request::input('id');
		$name = Request::input('name');
		$price = Request::input('price');
		$quantity = Request::input('quantity');
		$size = Request::input('size');
        DB::table('carts')->where('id', $id)->update([
					'name' => $name, 
					'price' => $price,
					'quantity' => $quantity,
					'size' => $size,
		]);
		Session::flash('success', 'Successfully updated product!');
        return Redirect::to('cart');
    }

    public function destroy($id)
    {
        DB::table('carts')->where('id', '=', $id)->delete();
        Session::flash('success', 'Successfully deleted product!');
        return Redirect::to('cart');
    }
	
	public function generateUniqueId($length)
	{
		$number = '';

		do {
			for ($i=$length; $i--; $i>0) {
				$number .= mt_rand(0,9);
			}
		} while ( !empty(DB::table('carts')->where('product_id', $number)->first(['id'])) );

		return $number;
	}

}
