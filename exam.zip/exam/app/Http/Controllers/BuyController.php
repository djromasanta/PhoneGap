<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Redirect;
use Request;
use Session;
use App\Cart;

class BuyController extends Controller
{
    public function index()
    {
        $cart = DB::table('carts')->paginate(15);
        return view('buy', ['products' => $cart]);
    }
	
	 public function create()
    {
        return view('create');
    }
	


}
