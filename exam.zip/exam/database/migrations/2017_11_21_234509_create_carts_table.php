<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\Cart;

// 1. Name
// 2. Price
// 3. Quantity
// 4. Size
// 5. Unique 4 digit code

class CreateCartsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 100);
			$table->float('price', 8, 2);
			$table->integer('quantity');
			$table->integer('size');
			$table->integer('product_id');
			
        });
		
		Cart::create([
            'name' => 'Apple',
            'price' => 2.00,
            'quantity' => 1,
			'size' => 1,
			'product_id' => $this->generateUniqueId(4),
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carts');
    }
	
	public function generateUniqueId($length)
	{
		$number = '';

		do {
			for ($i=$length; $i--; $i>0) {
				$number .= mt_rand(0,9);
			}
		} while ( !empty(DB::table('carts')->where('product_id', $number)->first(['id'])) );

		return $number;
	}
}
